-- V = Vo + a * dt

function love.load()

	love.graphics.setBackgroundColor (1,1,1)

	HEROIMAGE = love.graphics.newImage ("hero.gif")
	--ZOMBIEIMAGE = love.graphics.newImage ("zombie.gif")
	GROUNDIMAGE = love.graphics.newImage ("chao.png")
	
	GROUND =
	{
		x = 0,
		y = 450,
		w = 800,
		h = 160,	
		image = GROUNDIMAGE,
	}
	
	HERO = 
	{
		x = 400,
		y = 400,
		w = 33,
		h = 50,
		velocidadeInicial = 50,
		velocidadeFinal = 0,
		aceleracao = 10,
		image = HEROIMAGE,
		isJumping = false,
		isFalling = false,
		moveRight = false,
		moveLeft = false,
	}
	
	HERO2 = 
	{
		x = 600,
		y = 400,
		w = 33,
		h = 50,
		image = HEROIMAGE,
		velocidadeInicial = 50,
		velocidadeFinal = 0,
		aceleracao = 100,
		isJumping = false,
		isFalling = false
	}

	OBJETOS = { HERO , HERO2, GROUND}
	
	ZOMBIE = 
	{
		x = 0,
		y = 0,
		w = 0,
		h= 0,
		image = ZOMBIEIMAGE,
		velocidadeInicial = 50,
		velocidadeFinal = 0,
		aceleracao = 10,
		isJumping = false,
		isFalling = false
	}
	
end

function isColliding ( element1, element2, x, y ) --x e y s�o referentes a para onde o element1 est� indo

	if ( element1.x + element1.w + x < element2.x ) then return false
	
	elseif ( element2.x + element2.w < element1.x + x ) then return false
	
	elseif ( element1.y + element1.h + y < element2.y ) then return false
	
	elseif ( element2.y + element2.h < element1.y + y ) then return false
	
	end
	return true
	
end

function jump(element, dt) --fun��o para pular
	
	if element.isJumping == true then
	
		element.velocidadeFinal = element.velocidadeInicial - element.aceleracao*dt
		element.y = element.y - element.velocidadeFinal/75
	
		if HERO.y < 200 then
			element.isJumping = false
			element.isFalling = true
		end
	end
	
	if element.isFalling == true then
	
		element.velocidadeFinal = element.velocidadeInicial + element.aceleracao*dt
		element.y = element.y + element.velocidadeFinal/75
		element.isJumping = false
		
		if element.y > 399 then
			element.isFalling = false
        end
	end
end	

function love.update ( dt )

	if (HERO.isJumping) then 
		jump ( HERO, dt )
	end
	
	if (HERO.isFalling) then 
		jump ( HERO , dt )
	end
	
	if (HERO.moveRight) then
		HERO.x = HERO.x + 10*dt*HERO.aceleracao
	end
	
	if (HERO.moveLeft) then
		HERO.x = HERO.x - 10*dt*HERO.aceleracao
	end
	
end

function love.keypressed ( key )
	
	
	
	if key == 'escape' then
		love.event.push ( "quit" )
		
	elseif key == 'right' then
		if (isColliding(HERO,HERO2,10,0) == false) then 
			HERO.moveRight = true
			HERO.moveLeft = false
		end
		
	elseif key == 'left' then
	
		if (isColliding(HERO,HERO2,-10,0) == false) then 
			HERO.moveLeft = true
			HERO.moveRight = false
		end
	
	elseif key == ' ' then
	
		HERO.isJumping = true
		
	elseif key == nil then
		HERO.moveRight = false
		HERO.moveLeft = false
	end
end

function love.draw()
	love.graphics.draw( HERO.image, HERO.x , HERO.y )
	love.graphics.draw ( HERO2.image, HERO2.x, HERO2.y )
	love.graphics.draw ( GROUND.image, GROUND.x, GROUND.y )
	--love.graphics.polygon('fill', 0, 600, 400, 600, 400, 600, 0, 600)
end